const pedidoService = require('../services/pedidoService');

function criar(req, res, next) {
  try {
    const novoPedido = pedidoService.criarPedido(req.body);
    return res.status(201).json(novoPedido);
  } catch (erro) {
    return next(erro);
  }
}

function listar(req, res, next) {
  try {
    const lista = pedidoService.listarPedidos();
    return res.status(200).json(lista);
  } catch (erro) {
    return next(erro);
  }
}

function buscarPorId(req, res, next) {
  try {
    const pedido = pedidoService.buscarPedidoPorId(req.params.id);
    return res.status(200).json(pedido);
  } catch (erro) {
    return next(erro);
  }
}

function atualizarStatus(req, res, next) {
  try {
    const { status } = req.body || {};
    const pedidoAtualizado = pedidoService.atualizarStatusPedido(req.params.id, status);
    return res.status(200).json(pedidoAtualizado);
  } catch (erro) {
    return next(erro);
  }
}

module.exports = {
  criar,
  listar,
  buscarPorId,
  atualizarStatus
};
