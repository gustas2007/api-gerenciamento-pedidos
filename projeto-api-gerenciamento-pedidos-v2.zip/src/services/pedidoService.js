const AppError = require('../errors/AppError');

const TIPOS_VALIDOS = ['entrega', 'retirada'];
const PRIORIDADES_VALIDAS = ['baixa', 'normal', 'alta'];
const STATUS_VALIDOS = ['recebido', 'em_preparacao', 'enviado', 'entregue', 'cancelado'];

const TRANSICOES_PERMITIDAS = {
  recebido: ['em_preparacao', 'cancelado'],
  em_preparacao: ['enviado', 'cancelado'],
  enviado: ['entregue'],
  entregue: [],
  cancelado: []
};

let pedidos = [];
let proximoId = 1;

function resetarRepositorio() {
  pedidos = [];
  proximoId = 1;
}

function validarDadosCriacao(dados) {
  if (!dados || typeof dados !== 'object') {
    throw new AppError('O corpo da requisição é inválido.', 400);
  }

  const { cliente, tipo, valor, prioridade } = dados;

  if (typeof cliente !== 'string' || cliente.trim().length === 0) {
    throw new AppError('O campo "cliente" é obrigatório e não pode estar vazio.', 400);
  }

  if (typeof valor !== 'number' || Number.isNaN(valor) || valor <= 0) {
    throw new AppError('O campo "valor" deve ser numérico e maior que zero.', 400);
  }

  if (typeof tipo !== 'string' || !TIPOS_VALIDOS.includes(tipo)) {
    throw new AppError(
      `O campo "tipo" é inválido. Valores aceitos: ${TIPOS_VALIDOS.join(', ')}.`,
      400
    );
  }

  if (typeof prioridade !== 'string' || !PRIORIDADES_VALIDAS.includes(prioridade)) {
    throw new AppError(
      `O campo "prioridade" é inválido. Valores aceitos: ${PRIORIDADES_VALIDAS.join(', ')}.`,
      400
    );
  }
}

function criarPedido(dados) {
  validarDadosCriacao(dados);

  const novoPedido = {
    id: proximoId++,
    cliente: dados.cliente.trim(),
    tipo: dados.tipo,
    valor: dados.valor,
    prioridade: dados.prioridade,
    status: 'recebido'
  };

  pedidos.push(novoPedido);
  return novoPedido;
}

function listarPedidos() {
  return pedidos;
}

function buscarPedidoPorId(idParam) {
  const id = Number(idParam);

  if (!Number.isInteger(id) || id <= 0) {
    throw new AppError('Pedido não encontrado.', 404);
  }

  const pedido = pedidos.find((item) => item.id === id);

  if (!pedido) {
    throw new AppError('Pedido não encontrado.', 404);
  }

  return pedido;
}

function atualizarStatusPedido(idParam, novoStatus) {
  const pedido = buscarPedidoPorId(idParam);

  if (typeof novoStatus !== 'string' || !STATUS_VALIDOS.includes(novoStatus)) {
    throw new AppError(
      `O status informado é inválido. Estados aceitos: ${STATUS_VALIDOS.join(', ')}.`,
      400
    );
  }

  const transicoesPossiveis = TRANSICOES_PERMITIDAS[pedido.status] || [];

  if (!transicoesPossiveis.includes(novoStatus)) {
    throw new AppError(
      `Transição de status inválida: não é permitido alterar de "${pedido.status}" para "${novoStatus}".`,
      400
    );
  }

  pedido.status = novoStatus;
  return pedido;
}

module.exports = {
  TIPOS_VALIDOS,
  PRIORIDADES_VALIDAS,
  STATUS_VALIDOS,
  TRANSICOES_PERMITIDAS,
  criarPedido,
  listarPedidos,
  buscarPedidoPorId,
  atualizarStatusPedido,
  resetarRepositorio
};
