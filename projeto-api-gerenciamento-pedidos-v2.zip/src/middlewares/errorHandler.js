const AppError = require('../errors/AppError');

function errorHandler(err, req, res, next) {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      erro: 'JSON malformado no corpo da requisição.'
    });
  }

  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      erro: err.message
    });
  }

  console.error('[ERRO INTERNO]:', err);
  return res.status(500).json({
    erro: 'Erro interno inesperado no servidor.'
  });
}

module.exports = errorHandler;
