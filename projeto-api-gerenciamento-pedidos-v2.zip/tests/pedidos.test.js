const request = require('supertest');
const app = require('../src/app');
const pedidoService = require('../src/services/pedidoService');

describe('API de Gerenciamento de Pedidos', () => {
  beforeEach(() => {
    pedidoService.resetarRepositorio();
  });

  describe('POST /pedidos', () => {
    it('deve cadastrar um pedido válido com status inicial "recebido" e retornar HTTP 201', async () => {
      const resposta = await request(app)
        .post('/pedidos')
        .send({
          cliente: '  Carlos Silva  ',
          tipo: 'entrega',
          valor: 350,
          prioridade: 'normal'
        });

      expect(resposta.status).toBe(201);
      expect(resposta.body).toEqual({
        id: 1,
        cliente: 'Carlos Silva',
        tipo: 'entrega',
        valor: 350,
        prioridade: 'normal',
        status: 'recebido'
      });
    });

    it('deve retornar HTTP 400 quando o cliente for vazio ou apenas espaços', async () => {
      const resposta = await request(app)
        .post('/pedidos')
        .send({
          cliente: '   ',
          tipo: 'entrega',
          valor: 100,
          prioridade: 'normal'
        });

      expect(resposta.status).toBe(400);
      expect(resposta.body).toHaveProperty('erro');
    });

    it('deve retornar HTTP 400 quando o valor não for numérico ou for menor/igual a zero', async () => {
      const respostaZero = await request(app)
        .post('/pedidos')
        .send({
          cliente: 'Maria Souza',
          tipo: 'retirada',
          valor: 0,
          prioridade: 'baixa'
        });

      expect(respostaZero.status).toBe(400);
      expect(respostaZero.body).toHaveProperty('erro');

      const respostaTexto = await request(app)
        .post('/pedidos')
        .send({
          cliente: 'Maria Souza',
          tipo: 'retirada',
          valor: '350',
          prioridade: 'baixa'
        });

      expect(respostaTexto.status).toBe(400);
      expect(respostaTexto.body).toHaveProperty('erro');
    });

    it('deve retornar HTTP 400 quando tipo ou prioridade forem inválidos', async () => {
      const respostaTipo = await request(app)
        .post('/pedidos')
        .send({
          cliente: 'João Pedro',
          tipo: 'drone',
          valor: 50,
          prioridade: 'normal'
        });

      expect(respostaTipo.status).toBe(400);

      const respostaPrioridade = await request(app)
        .post('/pedidos')
        .send({
          cliente: 'João Pedro',
          tipo: 'entrega',
          valor: 50,
          prioridade: 'altissima'
        });

      expect(respostaPrioridade.status).toBe(400);
    });
  });

  describe('GET /pedidos', () => {
    it('deve listar todos os pedidos cadastrados com HTTP 200', async () => {
      await request(app).post('/pedidos').send({
        cliente: 'Carlos Silva',
        tipo: 'entrega',
        valor: 350,
        prioridade: 'normal'
      });

      const resposta = await request(app).get('/pedidos');

      expect(resposta.status).toBe(200);
      expect(Array.isArray(resposta.body)).toBe(true);
      expect(resposta.body).toHaveLength(1);
      expect(resposta.body[0].cliente).toBe('Carlos Silva');
    });
  });

  describe('GET /pedidos/:id', () => {
    it('deve retornar um pedido existente pelo ID com HTTP 200', async () => {
      await request(app).post('/pedidos').send({
        cliente: 'Ana Costa',
        tipo: 'retirada',
        valor: 120.5,
        prioridade: 'alta'
      });

      const resposta = await request(app).get('/pedidos/1');

      expect(resposta.status).toBe(200);
      expect(resposta.body.id).toBe(1);
      expect(resposta.body.cliente).toBe('Ana Costa');
    });

    it('deve retornar HTTP 404 ao consultar um ID inexistente', async () => {
      const resposta = await request(app).get('/pedidos/999');

      expect(resposta.status).toBe(404);
      expect(resposta.body).toHaveProperty('erro');
    });
  });

  describe('PATCH /pedidos/:id/status', () => {
    it('deve atualizar o status quando a transição for válida e retornar HTTP 200', async () => {
      await request(app).post('/pedidos').send({
        cliente: 'Carlos Silva',
        tipo: 'entrega',
        valor: 350,
        prioridade: 'normal'
      });

      const resposta = await request(app)
        .patch('/pedidos/1/status')
        .send({ status: 'cancelado' });

      expect(resposta.status).toBe(200);
      expect(resposta.body.status).toBe('cancelado');
    });

    it('deve retornar HTTP 400 quando a transição de status for inválida', async () => {
      await request(app).post('/pedidos').send({
        cliente: 'Carlos Silva',
        tipo: 'entrega',
        valor: 350,
        prioridade: 'normal'
      });

      // Tentando pular direto de "recebido" para "entregue"
      const resposta = await request(app)
        .patch('/pedidos/1/status')
        .send({ status: 'entregue' });

      expect(resposta.status).toBe(400);
      expect(resposta.body).toHaveProperty('erro');
    });

    it('deve retornar HTTP 404 ao tentar atualizar status de pedido inexistente', async () => {
      const resposta = await request(app)
        .patch('/pedidos/999/status')
        .send({ status: 'em_preparacao' });

      expect(resposta.status).toBe(404);
      expect(resposta.body).toHaveProperty('erro');
    });
  });
});
